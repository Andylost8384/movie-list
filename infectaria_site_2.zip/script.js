// script.js — hero rotation + age gate + basic interactions
document.addEventListener('DOMContentLoaded', function(){
  const heroImgs = ['1.png','2.png','3.png','4.png','5.png'];
  const heroTitles = ['Another Me','Little Chloe For OnlyTarts Again','Thanksgiving Dinner Idea','Got Milk?','Noi Feja For OnlyTarts'];
  const heroModels = ['Nika Nut','Little Chloe','Mila Pie','Little Chloe','Noi Feja'];

  let idx = 0;
  const heroImgEl = document.getElementById('heroImg');
  const heroTitle = document.getElementById('heroTitle');
  const heroModel = document.getElementById('heroModel');
  const prev = document.getElementById('prev');
  const next = document.getElementById('next');
  const dots = document.getElementById('heroDots');

  function renderDots(){
    dots.innerHTML = '';
    heroImgs.forEach((_,i)=>{
      const b = document.createElement('button');
      b.className = 'dot';
      b.style.width='10px';
      b.style.height='10px';
      b.style.borderRadius='50%';
      b.style.border='0';
      b.style.margin='0 6px';
      b.style.background = i===idx ? 'var(--accent)' : 'rgba(255,255,255,0.8)';
      b.addEventListener('click', ()=>{ idx=i; updateHero(); });
      dots.appendChild(b);
    });
  }

  function updateHero(){
    heroImgEl.src = heroImgs[idx];
    heroTitle.textContent = heroTitles[idx];
    heroModel.textContent = heroModels[idx];
    renderDots();
  }

  prev.addEventListener('click', ()=>{ idx = (idx-1+heroImgs.length)%heroImgs.length; updateHero();});
  next.addEventListener('click', ()=>{ idx = (idx+1)%heroImgs.length; updateHero();});

  renderDots();
  updateHero();
  setInterval(()=>{ idx = (idx+1)%heroImgs.length; updateHero(); }, 10000);

  // Age gate
  const ageGate = document.getElementById('ageGate');
  const over = document.getElementById('over18');
  const under = document.getElementById('under18');

  // check localStorage
  if(localStorage.getItem('infectaria_age_confirmed')==='true'){
    ageGate.style.display='none';
  } else {
    ageGate.style.display='flex';
  }

  over.addEventListener('click', ()=>{
    localStorage.setItem('infectaria_age_confirmed','true');
    ageGate.style.display='none';
  });
  under.addEventListener('click', ()=>{
    // redirect elsewhere
    window.location.href = 'https://www.google.com';
  });

  // year
  document.getElementById('year').textContent = new Date().getFullYear();
});
